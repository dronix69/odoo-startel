# shool_startel
Modulo para Escuela de Conducir 
este sistema cuenta con los siguientes modulos, contro de compras, registro de certificados de conduccion profesional, cursos, clases que realizan los profesores, modulo de control de practicas y un modulo para llevar una nomina basica de empleados. 
