# -*- coding: utf-8 -*-

from . import certificado
from . import cursos
from . import inherit_respartner
from . import inherit_sale
from . import nomina
from . import practicas
from . import compras
from . import simulador



